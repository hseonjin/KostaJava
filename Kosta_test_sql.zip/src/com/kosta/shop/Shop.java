package com.kosta.shop;

public class Shop {


	//구현해야 하는 부분: ApplicationMain.java 오류 없이 작동하도록 필요한 모든 메서드를 구현한다.
	
	
	
}
